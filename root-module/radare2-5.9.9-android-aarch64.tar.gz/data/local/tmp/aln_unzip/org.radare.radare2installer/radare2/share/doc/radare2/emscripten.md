# Building for the browser

## Install emscripten:

```bash
$ git clone git://github.com/kripken/emscripten.git
$ export PATH=/path/to/emscripten:$PATH
$ make clean
```

## Build radare

```bash
$ sys/emscripten.sh
```
